const express = require('express');
const app = express();
const server = require('http').createServer(app);
const path = require('path');
const morgan = require('morgan');
const keypress = require('keypress');
const fs = require('fs');
const opn = require('opn');

keypress(process.stdin);
process.stdin.setRawMode(true);
process.stdin.resume();

function handleKeyPressQ(res) {
    // Redirect to the HTML page
    res.redirect('/');
}

function handleKeyPressW(res) {
    // You can modify this logic to read 'w' specific data
    const jsonFilePath = path.join(__dirname, 'data_w.json');

    fs.readFile(jsonFilePath, 'utf8', (err, data) => {
        if (err) {
            if (err.code === 'ENOENT') {
                console.error('Error: data_w.json not found.');
            } else {
                console.error('Error reading JSON file:', err);
            }
            return;
        }

        console.log('Data from JSON file (w):', data);

        try {
            const jsonData = JSON.parse(data);
            console.log('Parsed JSON data (w):', jsonData);

            const videoUrl = jsonData.videoUrl;
            openFullScreen(videoUrl, res);

        } catch (parseError) {
            console.error('Error parsing JSON (w):', parseError);
        }
    });
}

function handleKeyPressE(res) {
    // You can modify this logic to read 'e' specific data
    const jsonFilePath = path.join(__dirname, 'data_e.json');

    fs.readFile(jsonFilePath, 'utf8', (err, data) => {
        if (err) {
            if (err.code === 'ENOENT') {
                console.error('Error: data_e.json not found.');
            } else {
                console.error('Error reading JSON file:', err);
            }
            return;
        }

        console.log('Data from JSON file (e):', data);

        try {
            const jsonData = JSON.parse(data);
            console.log('Parsed JSON data (e):', jsonData);

            const videoUrl = jsonData.videoUrl;
            openFullScreen(videoUrl, res);

        } catch (parseError) {
            console.error('Error parsing JSON (e):', parseError);
        }
    });
}

function openFullScreen(videoUrl, res) {
    console.log('Opening YouTube video in full screen:', videoUrl);

    var iframe = `
        <iframe 
            src="https://www.youtube.com/embed/${videoUrl}?autoplay=1" 
            allowfullscreen="" 
            frameborder="0" 
            width="100%" 
            height="100%">
        </iframe>
    `;

    // Replace the content of the body with the iframe
    res.send(iframe);
}

process.stdin.on('keypress', function (ch, key) {
    if (key) {
        switch (key.name) {
            case 'q':
                handleKeyPressQ(app.response);
                break;
            case 'w':
                handleKeyPressW(app.response);
                break;
            case 'e':
                handleKeyPressE(app.response);
                break;
        }
    }
});

app.set('port', process.env.TEST_PORT || 8080);

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan('dev'));

app.get('/', function (req, res) {
    res.sendFile(__dirname + '/public/index.html');
});

app.get('/remote', function (req, res) {
    res.sendFile(__dirname + '/public/remote.html');
});

server.listen(app.get('port'), function () {
    console.log('Express server listening on port ' + app.get('port'));
});
